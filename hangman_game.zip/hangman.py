import random

# Step 1: Predefined list of 5 words
word_list = ['apple', 'tiger', 'chair', 'magic', 'plant']

# Step 2: Choose a random word
chosen_word = random.choice(word_list)

# Step 3: Setup game variables
guessed_letters = []
correct_letters = ['_' for _ in chosen_word]
max_attempts = 6
wrong_guesses = 0

print("🎮 Welcome to Hangman!")
print("Guess the word letter by letter.")
print("You have 6 incorrect guesses. Let's begin!\n")

# Step 4: Game loop
while wrong_guesses < max_attempts and '_' in correct_letters:
    print("Word:", ' '.join(correct_letters))
    print(f"Wrong guesses left: {max_attempts - wrong_guesses}")
    print("Guessed letters:", ' '.join(guessed_letters))

    guess = input("Enter a letter: ").lower()

    if len(guess) != 1 or not guess.isalpha():
        print("❗ Please enter a single alphabet letter.\n")
        continue

    if guess in guessed_letters:
        print("⚠️ You've already guessed that letter.\n")
        continue

    guessed_letters.append(guess)

    if guess in chosen_word:
        print("✅ Good guess!\n")
        for i in range(len(chosen_word)):
            if chosen_word[i] == guess:
                correct_letters[i] = guess
    else:
        print("❌ Wrong guess!\n")
        wrong_guesses += 1

# Step 5: End of Game
if '_' not in correct_letters:
    print(f"🎉 Congratulations! You guessed the word: {chosen_word}")
else:
    print(f"💀 Game Over! The correct word was: {chosen_word}")
